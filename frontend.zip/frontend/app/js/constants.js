const AppSettings = {
  appTitle: 'Example Application',
  apiUrl: '/api/v1'
};

export default AppSettings;
