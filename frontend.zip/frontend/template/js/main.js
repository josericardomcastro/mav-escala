// -------- Execura content.resize -------- //
document.getElementsByTagName('nav')[0].style.height = window.innerHeight - document.getElementsByTagName('header')[0].clientHeight + "px";
document.getElementsByTagName('main')[0].style.height = window.innerHeight - document.getElementsByTagName('header')[0].clientHeight + "px";
// -------- Execura content.resize -------- //