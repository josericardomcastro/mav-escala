(function() {

	app.config(function($stateProvider) {
	    $stateProvider
        .state('painel', { 
            url: '/painel',
            templateUrl: 'app/components/painel/views/index.html',
            controller: 'PainelController'
        })
     
        .state('equipe', {
            url: '/equipe',
            templateUrl: 'app/components/equipe/views/index.html',
            controller: 'EquipeController'
        })

        .state('adicionarEquipe', {
            url: '/equipe/adicionar',
            templateUrl: 'app/components/equipe/views/formulario.html',
            controller: 'EquipeFormController'
        })

        .state('editarEquipe', {
            url: '/equipe/:id/editar',
            templateUrl: 'app/components/equipe/views/formulario.html',
            controller: 'EquipeFormController'
        })

        ;
	}).run(function($rootScope, $state){
        
        $state.go('painel');
    
    });

})();