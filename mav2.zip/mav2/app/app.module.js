var app = angular.module('app', 
	[
	'firebase', 
	'ui.router', 
	'ui.bootstrap', 
	'ngResource', 
	'toaster', 
	'blockUI',
	'ui.calendar', 
	'ui.date'
	]);


app.config(function(blockUIConfig) {

  // Change the default overlay message
  blockUIConfig.message = 'Carregando';
});