(function() {
	
	app.controller('EquipeController',['$scope', '$rootScope', '$state', '$stateParams', 'EquipeService', 'toaster',
								function($scope, $rootScope, $state, $stateParams, EquipeService, toaster) {
		
		$scope.equipe = EquipeService;		

		$scope.remove = function(id){
			if (EquipeService.$remove(id)){
				toaster.pop('success', "MAV", "Registro removido com sucesso!");
			}else{
				toaster.pop('error', "MAV", "Erro ao remover o registro!");
			}
		}
		

	}]);

	app.controller('EquipeFormController',['$scope', '$state', '$stateParams', 'EquipeService', 'TimeStampService', 'toaster', 
									function($scope, $state, $stateParams, EquipeService, TimeStampService, toaster) {
		if ($stateParams.id){
			$scope.cadastro = EquipeService.$getRecord($stateParams.id);
		}
		

		$scope.salvar = function(){
			if ($scope.cadastro.$id){
				var save = EquipeService.$save($scope.cadastro);
			}else{
				var save = EquipeService.$add($scope.cadastro);				
			}			

			if (save){
				var timestamp 	= TimeStampService;
				timestamp.value = Firebase.ServerValue.TIMESTAMP;
				timestamp.$save();

				toaster.pop('success', "MAV", "Registro salvo com sucesso!");
			}else{
				toaster.pop('error', "MAV", "Erro ao salvar o registro!");
			}

			$state.go('equipe');
		}

	}]);

})();