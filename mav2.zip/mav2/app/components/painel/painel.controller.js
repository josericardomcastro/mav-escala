(function() {
	
	app.controller('PainelController',
	['$scope', '$rootScope', 'blockUI','$firebase', '$firebaseArray', '$compile', '$uibModal',
	function($scope, $rootScope, blockUI, $firebase, $firebaseArray, $compile, $uibModal) {
		
		var firebaseEvents = new Firebase("https://ibak-mav.firebaseio.com/escala/2016/04");
		var events = $firebaseArray(firebaseEvents);

		$scope.eventoSelected = null;

		$scope.events = [events];

		$scope.newEvent = {title: '', start: ''};

		$scope.openModalEvento = function(evento){

			if (evento){
				$scope.evento = evento;
			}

			var modalInstance = $uibModal.open({
				animation: true,
				scope: $scope,
				templateUrl: 'app/components/painel/views/formulario.html',
				controller: 'EventoController'
			});
		}

		$scope.eventRender = function( event, element, view ) { 
	        element.attr({'tooltip': event.title,
	                     'tooltip-append-to-body': true});
	        $compile(element)($scope);
	    };

	    $scope.showEvento = function(date, jsEvent, view){
	    	$scope.eventoSelected = date;
	    	console.log(date);
	    };

	    $scope.alertOnDrop = function(event, delta, revertFunc, jsEvent, ui, view){
	    	console.log(event, delta);
	    };

		$scope.uiConfig = {
			calendar:{
				height: 500,
				editable: true,
				lang: 'pt-BR',
				header:{
					left: '',
					center: 'title',
					right: 'today prev,next'
				},
				eventClick: $scope.showEvento,
				eventDrop: $scope.alertOnDrop,
				eventResize: $scope.alertOnResize,
				eventRender: $scope.eventRender
			}
		};



	}]);

	app.controller('EventoController',
	['$scope', '$rootScope', 'blockUI','$firebase', '$firebaseArray', '$firebaseObject', '$uibModalInstance', 'EquipeService',
	function($scope, $rootScope, blockUI, $firebase, $firebaseArray, $firebaseObject, $uibModalInstance, EquipeService) {

		

		$scope.config = {
			datetimePicker: {
				startView: 'year'
			}
		};

		$scope.participantes 	= EquipeService;
		//console.log($scope.participantes);

		if (!$scope.evento){
			$scope.evento = {equipe:new Array()};
		}

		$scope.onTimeSet = function (newDate, oldDate) {
		    console.log(newDate);
		    console.log(moment.locale());
		}

		// $scope.beforeRender = function ($view, $dates, $leftDate, $upDate, $rightDate) {
		//     console.log($view);
		//     console.log($dates);
		//     //var index = Math.floor(Math.random() * $dates.length);
		//     //$dates[index].selectable = false;
		// }

		$scope.save = function(){
			// var data = moment($scope.evento.start);
			// var mes  = data.format('MM');
			// var ano  = data.format('YYYY');  
			// $scope.evento.start  = data.format('YYYY-MM-DD');
			console.log($scope.evento.start);

			// if ($scope.evento.$id){
			// 	var id = $scope.evento.$id;
			// 	var firebaseEvents = new Firebase("https://ibak-mav.firebaseio.com/escala/"+ano+"/"+mes+"/"+id);
			// 	var evento = $firebaseObject(firebaseEvents);

			// 	console.log($scope.evento);

			// 	evento.title 	= $scope.evento.title;
			// 	evento.start 	= $scope.evento.start;
			// 	evento.equipe 	= $scope.evento.equipe;

			// 	//evento = $scope.evento;

			// 	// console.log("save");
			// 	// console.log($scope.evento);
			// 	evento.$save().then(function(ref) {
			// 		console.log("certo",ref);
			// 	}).catch(function(error) {
			// 		console.log("Erro: " + error);
			// 	});
			// }else{
			// 	var firebaseEvents = new Firebase("https://ibak-mav.firebaseio.com/escala/"+ano+"/"+mes);
			// 	var events = $firebaseArray(firebaseEvents);
			// 	console.log("add");
			// 	console.log($scope.evento);
			// 	events.$add($scope.evento);
			// }		

			// events.$save($scope.evento).then(function(ref) {
			// 	var id = ref.key();
				
			// 	var eventoEquipe = new Firebase("https://ibak-mav.firebaseio.com/escala/"+ano+"/"+mes+"/"+id+"/equipe");
			// 	var equipe = $firebaseArray(eventoEquipe);

			// 	for(var i=0; i<$scope.evento.equipe.length; i++) {
			// 		equipe.$add($scope.evento.equipe[i]);
			// 	}

			// }).catch(function(error) {
			// 	console.log("Erro: " + error);
			// });

			$uibModalInstance.dismiss();
		}

		$scope.addEquipe = function(){
			$scope.evento.equipe.push({});
		}

		$scope.removeEquipe = function(e){
			var index = $scope.evento.equipe.indexOf(e);
			$scope.evento.equipe.splice(index, 1);	
		}

	}]);



})();
