(function() {
	
	app.controller('PainelController',
	['$scope', '$rootScope', 'blockUI','$firebase', '$firebaseArray', '$compile', '$uibModal',
	function($scope, $rootScope, blockUI, $firebase, $firebaseArray, $compile, $uibModal) {

		var firebaseEvents = new Firebase("https://ibak-mav.firebaseio.com/escala/2016/04");
		var events = $firebaseArray(firebaseEvents);



		$scope.events = [events];

		$scope.newEvent = {title: '', start: ''};

		$scope.openModalEvento = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/painel/views/formulario.html',
				controller: 'EventoController'
			});
		}

		$scope.eventRender = function( event, element, view ) { 
	        element.attr({'tooltip': event.title,
	                     'tooltip-append-to-body': true});
	        $compile(element)($scope);
	    };

	    $scope.alertOnEventClick = function( date, jsEvent, view){
	    	console.log(date);
	    };

	    $scope.alertOnDrop = function(event, delta, revertFunc, jsEvent, ui, view){
	    	console.log(event, delta);
	    };

		$scope.uiConfig = {
			calendar:{
				height: 500,
				editable: true,
				lang: 'pt-BR',
				header:{
					left: '',
					center: 'title',
					right: 'today prev,next'
				},
				eventClick: $scope.alertOnEventClick,
				eventDrop: $scope.alertOnDrop,
				eventResize: $scope.alertOnResize,
				eventRender: $scope.eventRender
			}
		};



	}]);

	app.controller('EventoController',
	['$scope', '$rootScope', 'blockUI','$firebase', '$firebaseArray', '$uibModalInstance', 'EquipeService',
	function($scope, $rootScope, blockUI, $firebase, $firebaseArray, $uibModalInstance, EquipeService) {

		$scope.evento 			= {equipe:[]}
		$scope.participantes 	= EquipeService;

		$scope.open = function() {
			$scope.popup.opened = true;
		};

		$scope.popup = { opened: false };

		$scope.dateOptions = {
			showWeeks: false,
			language: 'pt-BR'
		};

		$scope.save = function(){
			var data = moment($scope.evento.start);
			var mes  = data.format('MM');
			var ano  = data.format('YYYY');  
			$scope.evento.start  = data.format('YYYY-MM-DD');
			var equipe = $scope.evento.equipe;
			$scope.evento.equipe = {};

			


			var firebaseEvents = new Firebase("https://ibak-mav.firebaseio.com/escala/"+ano+"/"+mes);
			var events = $firebaseArray(firebaseEvents);

			var novoEvento = events.$add($scope.evento);			
			console.log(novoEvento);

			// newEvento.$save('equipe');			

			// for(var i=0; i<$scope.evento.equipe.length; i++) {
			// 	newEvento.equipe.$add($scope.evento.equipe[i]);
			// }


			//console.log(teste);
			$uibModalInstance.dismiss();
		}

		$scope.addEquipe = function(){
			$scope.evento.equipe.push([]);
		}

		$scope.removeEquipe = function(e){
			var index = $scope.evento.equipe.indexOf(e);
			$scope.evento.equipe.splice(index,1);
		}

	}]);



})();
