app.factory('EquipeService', function($firebaseArray){
  return $firebaseArray(new Firebase('https://ibak-mav.firebaseio.com/equipe'));
});

app.factory('Escala', function($firebaseArray){
  return $firebaseArray(new Firebase('https://ibak-mav.firebaseio.com/escala'));
});

app.factory('TimeStampService', function($firebaseObject){
  return $firebaseObject(new Firebase('https://ibak-mav.firebaseio.com/timestamp'));
});

