'use strict';

module.exports = {

  'serverport': 3000,

  'backend': {
	  'context': 'demandas',
	  'http': 'http://localhost:8080/',
	  'changeOrigin': true
  },
  
  
  'styles': {
    'src' : ['node_modules/capes-template-angular/dist/css/main.css','app/styles/**/*.less'],
    'dest': 'build/css'
  },

  'scripts': {
    'src' : ['app/js/**/*.js'],
    'dest': 'build/js'
  },

  'images': {
    'src' : ['node_modules/capes-template-angular/dist/images/**/*','app/images/**/*'],
    'dest': 'build/images'
  },
  
  'fonts': {
    'src' : ['node_modules/capes-template-angular/dist/fonts/**/*','app/fonts/**/*'],
    'dest': 'build/fonts'
  },

  'translate': {
    'src' : ['app/languages/**/*'],
    'dest': 'build/languages'
  },

  'views': {
    'watch': [
      'app/index.html',
      'app/views/*.html',
      'app/views/**/*.html'
    ],
    'src': 'app/views/**/*.html',
    'dest': 'app/js'
  },

  'gzip': {
    'src': 'build/**/*.{html,xml,json,css,js,js.map}',
    'dest': 'build/',
    'options': {}
  },

  'dist': {
    'root'  : 'build'
  },

  'browserify': {
    'entries'   : ['./app/js/main.js'],
    'bundleName': 'main.js',
    'sourcemap' : true
  },

  'test': {
    'karma': 'test/karma.conf.js',
    'protractor': 'test/protractor.conf.js'
  }

};