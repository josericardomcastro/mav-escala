'use strict';

var config  = require('../config');
var http    = require('http');
var express = require('express');
var gulp    = require('gulp');
var gutil   = require('gulp-util');
var morgan  = require('morgan');
var httpProxy = require('http-proxy');

gulp.task('server', function() {

  var server = express();
  
//  server.use(cookieParser())
  var router = express.Router();

  // log all requests to the console
  server.use('/',express.static(config.dist.root));
  

  var apiProxy = httpProxy.createProxyServer();

  server.all("/"+config.backend.context+"/rest/*", function(req, res){ 
	  apiProxy.web(req, res, { target: config.backend.http });
  });
  
  server.all("/"+config.backend.context+"/login", function(req, res){ 
	  apiProxy.web(req, res, { target: config.backend.http });
  });
  
  server.all("/"+config.backend.context+"/acs/*", function(req, res){ 
	  apiProxy.web(req, res, { target: config.backend.http });
  });
  

  // Start webserver if not already running
  var s = http.createServer(server);
  s.on('error', function(err){
    if(err.code === 'EADDRINUSE'){
      gutil.log('Development server is already started at port ' + config.serverport);
    }
    else {
      throw err;
    }
  });

  s.listen(config.serverport);

});