'use strict';

function configureRoutes($stateProvider, $locationProvider, $urlRouterProvider){

    $locationProvider.html5Mode(false);

    $stateProvider
    .state('Inicio', {
        url: '/',
        templateUrl: 'demanda/minhasDemandas.html',
        title: 'Minhas Demandas'
    })
    .state('NovaDemanda', {
        url: '/nova-demanda',
        templateUrl: 'demanda/novaDemandaDTI.html',
        controller: 'CadastrarDemandaController',
        title: 'Nova Demanda'
    })
    .state('MinhasDemandas', {
        url: '/minhas-demandas',
        templateUrl: 'demanda/minhasDemandas.html',
        controller: 'MinhasDemandasController',
        title: 'Minhas Demanda'
    })
    .state('demanda-show', {
        url: '/demanda/:numero',
        templateUrl: 'demanda/demanda.html',
        controller: 'VisualizarDemandaController',
        title: 'Demanda'
    })
    
    /* MODULO ESTADO */
    .state('estado', {
        url: '/estado',
        templateUrl: 'estado/index.html',
        controller: 'ListagemEstadoController',
        title: 'Estados'
    })
    .state('estado-cadastrar', {
        url: '/estado/cadastrar',
        templateUrl: 'estado/formulario.html',
        controller: 'CadastrarEstadoController',
        title: 'Estados'
    })
    .state('estado-editar', {
        url: '/estado/:id/editar',
        templateUrl: 'estado/formulario.html',
        controller: 'EditarEstadoController',
        title: 'Estados'
    })
    
    /* MODULO CATEGORIA */
    .state('categoria', {
        url: '/categoria',
        templateUrl: 'categoria/index.html',
        controller: 'ListagemCategoriaController',
        title: 'Categorias'
    })
    .state('categoria-cadastrar', {
        url: '/categoria/cadastrar',
        templateUrl: 'categoria/formulario.html',
        controller: 'CadastrarCategoriaController',
        title: 'Categorias'
    })
    .state('categoria-editar', {
        url: '/categoria/:id/editar',
        templateUrl: 'categoria/formulario.html',
        controller: 'EditarCategoriaController',
        title: 'Categorias'
    })
    
    /* MODULO SERVIÇO */
    .state('servico', {
        url: '/servico',
        templateUrl: 'servico/index.html',
        controller: 'ListagemServicoController',
        title: 'Serviços'
    })
    .state('servico-cadastrar', {
        url: '/servico/cadastrar',
        templateUrl: 'servico/formulario.html',
        controller: 'CadastrarServicoController',
        title: 'Serviços'
    })
    .state('servico-editar', {
        url: '/servico/:id/editar',
        templateUrl: 'servico/formulario.html',
        controller: 'EditarServicoController',
        title: 'Serviços'
    })
    
    /* MODULO FILA */
    .state('fila', {
        url: '/fila',
        templateUrl: 'fila/index.html',
        controller: 'ListagemFilaController',
        title: 'Filas'
    })
    .state('fila-cadastrar', {
        url: '/fila/cadastrar',
        templateUrl: 'fila/formulario.html',
        controller: 'CadastrarFilaController',
        title: 'Filas'
    })
    .state('fila-editar', {
        url: '/fila/:id/editar',
        templateUrl: 'fila/formulario.html',
        controller: 'EditarFilaController',
        title: 'Filas'
    });

    $urlRouterProvider.otherwise('/');
};

module.exports = { configureRoutes : configureRoutes };