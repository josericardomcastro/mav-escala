'use strict';

var AppSettings = {
	
};

module.exports = AppSettings;