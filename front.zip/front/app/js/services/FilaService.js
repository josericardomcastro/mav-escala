'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar filas 
 */
function FilaService($q, $http) {

	
  var service = {}; 

  // lista as filas paginada
  service.listar = function(pagina,max) {		
	  var deferred = $q.defer();
	  
	  $http.get('/demandas/rest/filas',{ 
		  params : { pagina : pagina, max:max}
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  // recupera uma fila
  service.recuperar = function(id){
	  var deferred = $q.defer();

	  $http.get( 'rest/filas/' + id).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };
  
  //salva um item
  service.salvar = function(fila, isNew) {
	  var deferred = $q.defer();
	  $http({
		  url: 'rest/filas' +  (isNew ? '' : '/' + fila.id ),
		  method: fila.id ? 'PUT' : 'POST',
	      data: fila
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  }
  
  //remove um item
  service.remover = function(fila){
	  var deferred = $q.defer();

	  $http.delete('rest/filas/' + fila.id)
	  .success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  return service;

}

servicesModule.service('FilaService', FilaService);