'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar estados 
 */
function EstadoService($q, $http) {

	
	var service 	= {}; 
	var server 	= "/demandas/";

	// lista os estados paginada
	service.listar = function(pagina,max) {		
		var deferred = $q.defer();
		  
		$http.get(server+'rest/estados',{ 
			params : { pagina : pagina, max:max}
		}).success(function(data) {
			deferred.resolve(data);
		}).error(function(err, status) {
			deferred.reject({data:err, status:status});
		});
	
		return deferred.promise;
	};

	// recupera um estado
	service.recuperar = function(id){
		var deferred = $q.defer();

		$http.get( server+'rest/estados/' + id).success(function(data) {
			deferred.resolve(data);
		}).error(function(err, status) {
			deferred.reject({data:err, status:status});
		});

		return deferred.promise;
	};
  
	//salva um item
	service.salvar = function(estado, isNew) {
		var deferred = $q.defer();
		$http({
			url: server+'rest/estados' +  (isNew ? '' : '/' + estado.id ),
			method: estado.id ? 'PUT' : 'POST',
			data: estado
		}).success(function(data) {
			deferred.resolve(data);
		}).error(function(err, status) {
			deferred.reject({data:err, status:status});
		});

		return deferred.promise;
	}
  
	//remove um item
	service.remover = function(estado){
		var deferred = $q.defer();

		$http.delete(server+'rest/estados/' + estado.id)
		.success(function(data) {
			deferred.resolve(data);
		}).error(function(err, status) {
			deferred.reject({data:err, status:status});
		});

		return deferred.promise;
	};

	return service;

}

servicesModule.service('EstadoService', EstadoService);