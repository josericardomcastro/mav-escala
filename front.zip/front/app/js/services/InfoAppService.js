//'use strict';
//
//var servicesModule = require('./_index.js');
//
//function InfoAppService($q, $http) {
//	var service = this;
//
//	service.obterInfo = function() {
//		var deferred = $q.defer();
//
//		$http.get('rest/infoApp').success(function(data) {
//			deferred.resolve(data);
//		}).error(function(err, status) {
//			deferred.reject({
//				data : err,
//				status : status
//			});
//		});
//
//		return deferred.promise;
//	};
//	
//	return service;
//
//}
//
//
//servicesModule.service('InfoAppService', InfoAppService);