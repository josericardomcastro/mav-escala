'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar aplicacoes 
 */
function AplicacaoService($q, $http) {

	
  var service 	= {}; 
  var server 	= "/demandas/";

  // lista as aplicacoes paginada
  service.listar = function(pagina,max) {
		
    var deferred 	= $q.defer();    

    $http.get(server+'rest/aplicacoes',{ 
      params : { pagina : pagina, max:max}
    }).success(function(data) {
        deferred.resolve(data);
    }).error(function(err, status) {
        deferred.reject({data:err, status:status});
    });

    return deferred.promise;
  };

  // recupera uma aplicacao
  service.recuperar = function(id){
    var deferred = $q.defer();

    $http.get( server+'rest/aplicacoes/' + id).success(function(data) {
        deferred.resolve(data);
    }).error(function(err, status) {
        deferred.reject({data:err, status:status});
    });

    return deferred.promise;
  };

  return service;

}

servicesModule.service('AplicacaoService', AplicacaoService);