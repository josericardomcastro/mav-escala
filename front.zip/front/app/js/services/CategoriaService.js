'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar categorias 
 */
function CategoriaService($q, $http) {

	
  var service = {}; 

  // lista as categorias paginada
  service.listar = function(pagina,max) {		
	  var deferred = $q.defer();
	  
	  $http.get('/demandas/rest/categorias',{ 
		  params : { pagina : pagina, max:max}
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  // recupera uma categoria
  service.recuperar = function(id){
	  var deferred = $q.defer();

	  $http.get( 'rest/categorias/' + id).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };
  
  //salva um item
  service.salvar = function(categoria, isNew) {
	  var deferred = $q.defer();
	  $http({
		  url: 'rest/categorias' +  (isNew ? '' : '/' + categoria.id ),
		  method: categoria.id ? 'PUT' : 'POST',
	      data: categoria
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  }
  
  //remove um item
  service.remover = function(categoria){
	  var deferred = $q.defer();

	  $http.delete('rest/categorias/' + categoria.id)
	  .success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  return service;

}

servicesModule.service('CategoriaService', CategoriaService);