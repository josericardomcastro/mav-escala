'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar demandas 
 */
function DemandaService($q, $http) {

	
  var service 	= {}; 
  var server 	= "/demandas/";

  // lista as demandas paginada
  service.listar = function(pagina,max) {		
	  var deferred = $q.defer();
	  
	  $http.get(server+'rest/demandas',{ 
		  params : { pagina : pagina, max:max}
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };
  
  //lista as demandas paginada do usuário
  service.listarMinhasDemandas = function(pagina,max) {		
	  var deferred = $q.defer();
	  
	  $http.get(server+'rest/demandas/minhasDemandas',{ 
		  params : { pagina : pagina, max:max}
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  // recupera uma demanda
  service.recuperar = function(id){
	  var deferred = $q.defer();

	  $http.get( server+'rest/demandas/' + id).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };
  
  //salva uma demanda
  service.salvar = function(demanda, isNew) {
	  var deferred = $q.defer();
	  $http({
		  url: server+'rest/demandas' +  (isNew ? '' : '/' + demanda.id ),
		  method: demanda.id ? 'PUT' : 'POST',
	      data: demanda
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  }
  
  //remove um item
  service.remover = function(demanda){
	  var deferred = $q.defer();

	  $http.delete(server+'rest/demandas/' + demanda.id)
	  .success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  return service;

}

servicesModule.service('DemandaService', DemandaService);