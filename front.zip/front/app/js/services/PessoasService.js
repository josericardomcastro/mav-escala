//'use strict';
//
//var servicesModule = require('./_index.js');
//
//
///**
// * servico para tratar pessoas 
// */
//function PessoasService( $q, $http) {
//
//	
//  var service = {}; 
//
//  // lista as pessoas paginado
//  service.listar = function(pagina,max) {
//		
//    var deferred = $q.defer();
//
//    $http.get('rest/pessoas',{ 
//      params : { pagina : pagina, max:max}
//    }).success(function(data) {
//        deferred.resolve(data);
//    }).error(function(err, status) {
//        deferred.reject({data:err, status:status});
//    });
//
//    return deferred.promise;
//  };
//
//  // recupera uma pessoa
//  service.recuperar = function(id){
//    var deferred = $q.defer();
//
//    $http.get( 'rest/pessoas/' + id).success(function(data) {
//        deferred.resolve(data);
//    }).error(function(err, status) {
//        deferred.reject({data:err, status:status});
//    });
//
//    return deferred.promise;
//  };
//
//  // remove uma pessoa
//  service.remover = function(pessoa){
//     var deferred = $q.defer();
//
//    $http.delete('rest/pessoas/' + pessoa.id)
//    .success(function(data) {
//        deferred.resolve(data);
//    }).error(function(err, status) {
//        deferred.reject({data:err, status:status});
//    });
//
//    return deferred.promise;
//  };
//
//
//  // salva uma pessoa 
//  service.salvar = function(pessoa){
//    var deferred = $q.defer();
//    $http({
//      url: 'rest/pessoas/' +  (pessoa.id ? pessoa.id : '' ),
//      method: pessoa.id ? 'PUT' : 'POST',
//      data: pessoa
//    }).success(function(data) {
//        deferred.resolve(data);
//    }).error(function(err, status) {
//    	deferred.reject({data:err, status:status});
//    });
//
//    return deferred.promise;
//  }
//
//  return service;
//
//}
//
//servicesModule.service('PessoasService', PessoasService);