'use strict';

var servicesModule = require('./_index.js');


/**
 * servico para tratar serviços 
 */
function ServicoService($q, $http) {

	
  var service = {}; 

  // lista os serviços paginada
  service.listar = function(pagina,max) {		
	  var deferred = $q.defer();
	  
	  $http.get('/demandas/rest/servicos',{ 
		  params : { pagina : pagina, max:max}
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  // recupera um serviço
  service.recuperar = function(id){
	  var deferred = $q.defer();

	  $http.get( 'rest/servicos/' + id).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };
  
  //salva um item
  service.salvar = function(servico, isNew) {
	  var deferred = $q.defer();
	  $http({
		  url: 'rest/servicos' +  (isNew ? '' : '/' + servico.id ),
		  method: servico.id ? 'PUT' : 'POST',
	      data: servico
	  }).success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  }
  
  //remove um item
  service.remover = function(servico){
	  var deferred = $q.defer();

	  $http.delete('rest/servicos/' + servico.id)
	  .success(function(data) {
		  deferred.resolve(data);
	  }).error(function(err, status) {
		  deferred.reject({data:err, status:status});
	  });

	  return deferred.promise;
  };

  return service;

}

servicesModule.service('ServicoService', ServicoService);