'use strict';

var controllersModule = require('../_index');



var CadastrarCategoriaController = ["$http" ,"$scope", "toaster", "$location", "CategoriaService",
	function($http ,$scope, toaster, $location, CategoriaService) {

	var vm 		= $scope;
	vm.isNew 	= true;
	
	vm.categoria = {};

	vm.init = function() {		
		console.log("CadastrarCategoriaController");
	}
	
	vm.salvar = function() {
		CategoriaService.salvar(vm.categoria, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Categoria salva com sucesso');
			$location.path("/categoria");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	vm.init();
}];

controllersModule.controller('CadastrarCategoriaController', CadastrarCategoriaController);