'use strict';

var controllersModule = require('../_index');



var EditarCategoriaController = ["$http" ,"$scope", "$stateParams", "toaster", "$location", "CategoriaService",
	function($http ,$scope, $stateParams, toaster, $location, CategoriaService) {

	var vm 			= $scope;	
	vm.categoria 	= {};
	vm.isNew 		= false;

	vm.init = function() {
		console.log($stateParams.id);
		CategoriaService.recuperar($stateParams.id)
		  	.then(function(categoria){
		  		vm.categoria = categoria;
		  		console.log(vm.categoria);
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a categoria informada");
		});
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.categoria));
		CategoriaService.salvar(vm.categoria, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Categoria salva com sucesso');
			$location.path("/categoria");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	

	vm.init();
}];

controllersModule.controller('EditarCategoriaController', EditarCategoriaController);