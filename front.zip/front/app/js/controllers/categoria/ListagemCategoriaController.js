'use strict';

var controllersModule = require('../_index');

var ListagemCategoriaController = ["$http" ,"$scope", "toaster", "CategoriaService",
	function($http ,$scope, toaster, CategoriaService) {

	var vm = $scope;
	
	// cria a base para lista de categorias
	vm.categorias = {
			items: [],
			count:0,
			pagina: 1,
			maxResults: 10
	};

	vm.init = function() {
		CategoriaService.listar(1,100)
		  	.then(function(dados){
		  		vm.categorias = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de categorias");
		});
	}
	
	vm.remover = function(categoria) {
		if (confirm('Confirma a remoção da categoria #'+ categoria.id + ' ' + categoria.nome + '?')){
			CategoriaService.remover(categoria).then(function(){
				toaster.pop('success', 'Sistema', "Categoria removida com sucesso");
				vm.init();	 
			}).catch(function(error){
				toaster.pop('error', 'Sistema', "Não foi possivel remover a categoria");
			});  
	    }	 
	}	

	vm.init();
}];

controllersModule.controller('ListagemCategoriaController', ListagemCategoriaController);