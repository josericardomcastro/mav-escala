'use strict';

var controllersModule = require('../_index');



var MinhasDemandasController = ["$http" ,"$scope", "toaster", "DemandaService",
	function($http ,$scope, toaster, DemandaService) {

	var vm = $scope;
	vm.demandas = {
			items: [],
			count:0,
			pagina: 1,
			maxResults: 8
	};

	vm.init = function() {
		console.log("MinhasDemandasController");
		DemandaService.listarMinhasDemandas(vm.demandas.pagina, vm.demandas.maxResults)
		  	.then(function(dados){
		  		vm.demandas = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de demandas");
		});
	}
	

	vm.init();
}];

controllersModule.controller('MinhasDemandasController', MinhasDemandasController);