'use strict';

var controllersModule = require('../_index');



var CadastrarDemandaController = ["$http" ,"$scope", "toaster", "$location", "DemandaService", "AplicacaoService", "ServicoService", "FilaService", "CategoriaService", "EstadoService",
	function($http ,$scope, toaster, $location, DemandaService, AplicacaoService, ServicoService, FilaService, CategoriaService, EstadoService) {

	var vm 		= $scope;
	vm.isNew 	= true;
	
	vm.demanda 	= {
			demandaHistorico : []
	};

	vm.init = function() {
		
		EstadoService.recuperar(1)
		  	.then(function(estado){
		  		vm.estado = estado;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar o estado informado");
		});
		
		AplicacaoService.listar(1,100)
		  	.then(function(dados){
		  		vm.aplicacoes = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de aplicações");
		});
		
		ServicoService.listar(1,100)
	  	.then(function(dados){
	  		vm.servicos = dados;
	  	})
	  	.catch(function(err){
	  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de serviços");
	  	});
		
		FilaService.listar(1,100)
	  	.then(function(dados){
	  		vm.filas = dados;
	  	})
	  	.catch(function(err){
	  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de filas");
	  	});
		
		CategoriaService.listar(1,100)
	  	.then(function(dados){
	  		vm.categorias = dados;
	  	})
	  	.catch(function(err){
	  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de categorias");
	  	});
	}

	vm.salvar = function() {
		
		vm.demandaHistorico.assunto = vm.demanda.assunto;
		vm.demandaHistorico.estado 	= vm.estado;
		vm.demanda.demandaHistorico.push(vm.demandaHistorico); 
		
		DemandaService.salvar(vm.demanda, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Demanda salva com sucesso');
			$location.path("/minhas-demandas");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	vm.init();
}];

controllersModule.controller('CadastrarDemandaController', CadastrarDemandaController);