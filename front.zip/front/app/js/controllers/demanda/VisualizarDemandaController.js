'use strict';

var controllersModule = require('../_index');



var VisualizarDemandaController = ["$http" ,"$scope", "$stateParams", "toaster", "$location", "EstadoService",
	function($http ,$scope, $stateParams, toaster, $location, EstadoService) {

	var vm 		= $scope;	
	vm.demanda 	= {};
	vm.isNew 	= false;

	vm.init = function() {
		console.log($stateParams.numero);
		DemandaService.recuperar($stateParams.numero)
		  	.then(function(demanda){
		  		vm.demanda = demanda;
		  		console.log(vm.demanda);
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a demanda informada - #"+$stateParams.numero);
		});
	}

	

	vm.init();
}];

controllersModule.controller('VisualizarDemandaController', VisualizarDemandaController);