'use strict';

var controllersModule = require('../_index');

var ListagemFilaController = ["$http" ,"$scope", "toaster", "FilaService",
	function($http ,$scope, toaster, FilaService) {

	var vm = $scope;
	
	// cria a base para lista de filas
	vm.filas = {
			items: [],
			count:0,
			pagina: 1,
			maxResults: 10
	};

	vm.init = function() {
		FilaService.listar(1,100)
		  	.then(function(dados){
		  		vm.filas = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de filas");
		});
	}
	
	vm.remover = function(fila) {
		if (confirm('Confirma a remoção da fila #'+ fila.id + ' ' + fila.nome + '?')){
			FilaService.remover(fila).then(function(){
				toaster.pop('success', 'Sistema', "Fila removida com sucesso");
				vm.init();	 
			}).catch(function(error){
				toaster.pop('error', 'Sistema', "Não foi possivel remover a fila");
			});  
	    }	 
	}	

	vm.init();
}];

controllersModule.controller('ListagemFilaController', ListagemFilaController);