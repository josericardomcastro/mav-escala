'use strict';

var controllersModule = require('../_index');



var EditarFilaController = ["$http" ,"$scope", "$stateParams", "toaster", "$location", "FilaService",
	function($http ,$scope, $stateParams, toaster, $location, FilaService) {

	var vm 		= $scope;	
	vm.fila 	= {};
	vm.isNew 	= false;	

	vm.init = function() {
		console.log($stateParams.id);
		FilaService.recuperar($stateParams.id)
		  	.then(function(fila){
		  		vm.fila = fila;
		  		console.log(vm.fila);
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a fila informada");
		});
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.fila));
		FilaService.salvar(vm.fila, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Fila salva com sucesso');
			$location.path("/fila");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	

	vm.init();
}];

controllersModule.controller('EditarFilaController', EditarFilaController);