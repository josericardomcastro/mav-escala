'use strict';

var controllersModule = require('../_index');



var CadastrarFilaController = ["$http" ,"$scope", "toaster", "$location", "FilaService",
	function($http ,$scope, toaster, $location, FilaService) {

	var vm 		= $scope;
	vm.isNew 	= true;
	
	vm.fila = {
			filaResponsavel: []
	};

	vm.init = function() {		
		console.log("CadastrarFilaController");
	}
	
	vm.adicionarResponsavel = function(){
		vm.fila.filaResponsavel.push({}); 
	}
	
	vm.removerResponsavel = function(responsavel) {
		vm.fila.filaResponsavel.splice($scope.fila.filaResponsavel.indexOf(responsavel), 1);
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.fila));
		FilaService.salvar(vm.fila, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Fila salva com sucesso');
			$location.path("/fila");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	vm.init();
}];

controllersModule.controller('CadastrarFilaController', CadastrarFilaController);