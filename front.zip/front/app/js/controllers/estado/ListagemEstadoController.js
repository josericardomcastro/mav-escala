'use strict';

var controllersModule = require('../_index');

var ListagemEstadoController = ["$http" ,"$scope", "toaster", "EstadoService",
	function($http ,$scope, toaster, EstadoService) {

	var vm = $scope;
	
	// cria a base para lista de estados
	vm.estados = {
			items: [],
			count:0,
			pagina: 1,
			maxResults: 10
	};

	vm.init = function() {
		EstadoService.listar(1,100)
		  	.then(function(dados){
		  		vm.estados = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de estados");
		});
	}
	
	vm.remover = function(estado) {
		if (confirm('Confirma a remoção do estado #'+ estado.id + ' ' + estado.nome + '?')){
			EstadoService.remover(estado).then(function(){
				toaster.pop('success', 'Sistema', "Estado removido com sucesso");
				vm.init();	 
			}).catch(function(error){
				toaster.pop('error', 'Sistema', "Não foi possivel remover o estado");
			});  
	    }	 
	}	

	vm.init();
}];

controllersModule.controller('ListagemEstadoController', ListagemEstadoController);