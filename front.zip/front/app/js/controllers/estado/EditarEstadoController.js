'use strict';

var controllersModule = require('../_index');



var EditarEstadoController = ["$http" ,"$scope", "$stateParams", "toaster", "$location", "EstadoService",
	function($http ,$scope, $stateParams, toaster, $location, EstadoService) {

	var vm 		= $scope;	
	vm.estado 	= {};
	vm.isNew 	= false;

	vm.init = function() {
		console.log($stateParams.id);
		EstadoService.recuperar($stateParams.id)
		  	.then(function(estado){
		  		vm.estado = estado;
		  		console.log(vm.estado);
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar o estado informado");
		});
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.estado));
		EstadoService.salvar(vm.estado, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Estado salvo com sucesso');
			$location.path("/estado");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	

	vm.init();
}];

controllersModule.controller('EditarEstadoController', EditarEstadoController);