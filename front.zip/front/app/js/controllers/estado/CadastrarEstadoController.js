'use strict';

var controllersModule = require('../_index');



var CadastrarEstadoController = ["$http" ,"$scope", "toaster", "$location", "EstadoService",
	function($http ,$scope, toaster, $location, EstadoService) {

	var vm 		= $scope;
	vm.isNew 	= true;
	
	vm.estado = {};

	vm.init = function() {		
		console.log("CadastrarEstadoController");
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.estado));
		EstadoService.salvar(vm.estado, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Estado salvo com sucesso');
			$location.path("/estado");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	vm.init();
}];

controllersModule.controller('CadastrarEstadoController', CadastrarEstadoController);