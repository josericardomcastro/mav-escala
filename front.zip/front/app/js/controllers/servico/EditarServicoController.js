'use strict';

var controllersModule = require('../_index');



var EditarServicoController = ["$http" ,"$scope", "$stateParams", "toaster", "$location", "ServicoService",
	function($http ,$scope, $stateParams, toaster, $location, ServicoService) {

	var vm 		= $scope;	
	vm.servico 	= {};
	vm.isNew 	= false;
	
	vm.optionBoolean = [{id: 'S', name: 'SIM'},{id: 'N', name: 'NÃO'}];

	vm.init = function() {
		console.log($stateParams.id);
		ServicoService.recuperar($stateParams.id)
		  	.then(function(servico){
		  		vm.servico = servico;
		  		console.log(vm.servico);
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar o serviço informado");
		});
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.servico));
		ServicoService.salvar(vm.servico, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Serviço salvo com sucesso');
			$location.path("/servico");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	

	vm.init();
}];

controllersModule.controller('EditarServicoController', EditarServicoController);