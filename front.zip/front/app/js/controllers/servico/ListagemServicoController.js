'use strict';

var controllersModule = require('../_index');

var ListagemServicoController = ["$http" ,"$scope", "toaster", "ServicoService",
	function($http ,$scope, toaster, ServicoService) {

	var vm = $scope;
	
	// cria a base para lista de serviços
	vm.servicos = {
			items: [],
			count:0,
			pagina: 1,
			maxResults: 10
	};
	
	vm.init = function() {
		ServicoService.listar(1,100)
		  	.then(function(dados){
		  		vm.servicos = dados;
		  	})
		  	.catch(function(err){
		  		toaster.pop('error', 'Sistema', "Não foi possivel recuperar a listagem de serviços");
		});
	}
	
	vm.remover = function(servico) {
		if (confirm('Confirma a remoção do serviço #'+ servico.id + ' ' + servico.nome + '?')){
			ServicoService.remover(servico).then(function(){
				toaster.pop('success', 'Sistema', "Serviço removido com sucesso");
				vm.init();	 
			}).catch(function(error){
				toaster.pop('error', 'Sistema', "Não foi possivel remover o serviço");
			});  
	    }	 
	}	

	vm.init();
}];

controllersModule.controller('ListagemServicoController', ListagemServicoController);