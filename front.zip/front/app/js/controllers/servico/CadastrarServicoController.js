'use strict';

var controllersModule = require('../_index');



var CadastrarServicoController = ["$http" ,"$scope", "toaster", "$location", "ServicoService",
	function($http ,$scope, toaster, $location, ServicoService) {

	var vm 		= $scope;
	vm.isNew 	= true;
	
	vm.optionBoolean = [{id: 'S', name: 'SIM'},{id: 'N', name: 'NÃO'}];
	
	vm.servico 	= {};

	vm.init = function() {		
		console.log("CadastrarServicoController");
	}
	
	vm.salvar = function() {
		console.log(JSON.stringify(vm.servico));
		ServicoService.salvar(vm.servico, vm.isNew).then(function() {
			toaster.pop('success','Sistema','Serviço salvo com sucesso');
			$location.path("/servico");
		}).catch(function(err){
			switch(err.status) {
				case 409:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Tente novamente mais tarde.');
				break;
				case 412:
				toaster.pop('error','Sistema','Ocorreu um erro ao contectar o servidor web.' +
				' Contacte o administrador.');
				break;
				case 422:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar: ' + err.data.detail);
				break;
				default:
				toaster.pop('error','Sistema','Ocorreu um erro ao salvar');
			}
		});	
	};

	vm.init();
}];

controllersModule.controller('CadastrarServicoController', CadastrarServicoController);