'use strict';


var OnRun = ['$rootScope','AppSettings', function ($rootScope,AppSettings) {

	// InfoAppService.obterInfo().then(function(info){
		
	// 	AppSettings.identificador = info.identificador;
	// 	AppSettings.usuarioLogado = info.usuarioLogado;
	// 	AppSettings.perfil = info.perfil;
	// 	AppSettings.urlLogout = info.urlLogout;
	// 	$rootScope.AppSettings =AppSettings;
	// });
}]

module.exports = OnRun;