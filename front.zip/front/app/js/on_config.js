'use strict';

var routes = require('./routes');
var translates = require('./translates');

/**
 * @ngInject
 */
var OnConfig = ['$stateProvider', '$locationProvider', '$urlRouterProvider','$translateProvider',
                function ($stateProvider, $locationProvider, $urlRouterProvider,$translateProvider) {

	//configura as rotas do sistema
	routes.configureRoutes($stateProvider, $locationProvider, $urlRouterProvider);

	// configura suporte a internacionalização
	translates.configureTranslate($translateProvider);

}]

module.exports = OnConfig;